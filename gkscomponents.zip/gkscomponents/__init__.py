IS_RELEASE = True

from .TabBar import tab_bar
from .TabBar import TabBarItemData
